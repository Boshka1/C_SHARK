import copy
import torch


class Config:
    """Конфигурация системы размещения объектов."""

    # ---------- Параметры области ----------
    AREA_SIZE = 100           # размер участка в метрах (квадрат AREA_SIZE x AREA_SIZE)
    GRID_RESOLUTION = 1       # шаг дискретной сетки в метрах (1 м на клетку)

    # ---------- Параметры объектов ----------
    NUM_OBJECTS = 10          # перезаписывается после загрузки данных

    # ---------- Параметры дорог ----------
    ROAD_WIDTH = 6            # ширина дороги, м
    MIN_DIST_TO_ROAD = 5      # минимальное расстояние от объекта до дороги, м
    IDEAL_ROAD_BAND = 3       # «коридор» от MIN_DIST_TO_ROAD до MIN_DIST_TO_ROAD+IDEAL_ROAD_BAND,
                              # внутри которого начисляется бонус за близость к дороге
    # Список кортежей (тип, координата):
    #   'h' — горизонтальная дорога (Y = coord)
    #   'v' — вертикальная   дорога (X = coord)
    ROADS = [('h', 50)]

    # ---------- Параметры RNN ----------
    INPUT_SIZE = 12
    HIDDEN_SIZE = 128
    OUTPUT_SIZE = 2
    NUM_LAYERS = 2

    # ---------- Параметры обучения ----------
    EPOCHS = 100
    BATCH_SIZE = 32
    LEARNING_RATE = 0.001
    NUM_SAMPLES = 1000        # сколько траекторий генерируется для обучения

    # ---------- Штрафы и бонусы (метрика качества) ----------
    # Штрафы (вычитаются из общей метрики)
    PENALTY_COLLISION       = 100.0   # пересечение с другим объектом
    PENALTY_ROAD_VIOLATION  = 50.0    # объект ближе MIN_DIST_TO_ROAD к дороге
    PENALTY_FIRE_SAFETY     = 30.0    # нарушение противопожарного норматива

    # Бонусы (прибавляются к общей метрике)
    BONUS_COMPACTNESS       = 10.0    # компактная пара объектов (зазор около минимума)
    BONUS_ROAD_PROXIMITY    = 15.0    # объект расположен в идеальной полосе у дороги
    BONUS_TECH_LINK         = 200.0   # технологически связанная пара объектов близко

    # ---------- Пути ----------
    MODEL_SAVE_PATH = 'saved_models/placement_model.pth'
    RESULTS_PATH    = 'saved_models/placement_results.pkl'

    # ---------- Файлы данных ----------
    DISTANCES_FILE       = 'Минимальные расстояния.xlsx'
    SEQUENCE_FILE        = 'Технологическая последовательность.xlsx'
    CHARACTERISTICS_FILE = 'Характеристики объектов.xlsx'

    DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    SEED   = 42

    def __init__(self):
        # Поля, которые заполняются после загрузки данных
        self.sequence_data = None
        self.characteristics_tensor = None

    def clone(self):
        """Глубокая копия — удобно, когда GUI меняет параметры на лету."""
        return copy.deepcopy(self)
