import pandas as pd
import torch


class DataLoader:
    def __init__(self, config):
        self.config = config
        self.distances = None
        self.sequence = None
        self.characteristics = None

    def load_data(self):
        """Загрузка данных из Excel файлов"""
        print("Загрузка данных...")

        # Загрузка характеристик объектов (сначала, чтобы узнать категории)
        characteristics_df = pd.read_excel(self.config.CHARACTERISTICS_FILE, index_col=0)
        
        # Извлекаем категории пожарной опасности (последний столбец)
        categories = characteristics_df.iloc[:, -1].tolist()
        print(f"Категории объектов: {categories}")
        
        char_data = characteristics_df[['Длина', 'Ширина', 'Радиус']]
        char_data = char_data.apply(pd.to_numeric, errors='coerce').fillna(0)
        self.characteristics = torch.tensor(char_data.values, dtype=torch.float32)

        # Загрузка минимальных расстояний — берём подматрицу по реальным категориям
        distances_df = pd.read_excel(self.config.DISTANCES_FILE, index_col=0)
        sub_distances = distances_df.loc[categories, categories]
        self.distances = torch.tensor(sub_distances.values, dtype=torch.float32)
        print(f"Матрица расстояний: {self.distances.shape[0]}x{self.distances.shape[1]} "
              f"(категории {categories[0]}–{categories[-1]})")

        # Загрузка технологической последовательности
        sequence_df = pd.read_excel(self.config.SEQUENCE_FILE, index_col=0)
        sequence_df = sequence_df.apply(pd.to_numeric, errors='coerce').fillna(0)
        self.sequence = torch.tensor(sequence_df.values, dtype=torch.float32)
        
        # Сохраняем в конфиг для глобального доступа
        self.config.characteristics_tensor = self.characteristics
        self.config.NUM_OBJECTS = self.characteristics.shape[0]

        print(f"Загружено {self.characteristics.shape[0]} объектов")
        return self.distances, self.sequence, self.characteristics

    def get_num_objects(self):
        return self.characteristics.shape[0]
