import matplotlib.patches as patches
import matplotlib.pyplot as plt
import numpy as np
import torch


class Visualizer:
    """Визуализация размещения объектов и истории обучения."""

    def __init__(self, config):
        self.config = config

    # ------------------------------------------------------------------ #

    def visualize_placement(self, placer, positions, quality_breakdown=None,
                            save_path='placement_result.png',
                            show_grid_lines=True, show=True):
        """Полная визуализация размещения.

        Args:
            placer: ObjectPlacer (нужен для форм и индексов).
            positions: список (x, y) для каждого размещённого объекта.
            quality_breakdown: словарь с метриками (см. placer.calculate_quality_breakdown).
            show_grid_lines: рисовать ли дискретную сетку каждые GRID_RESOLUTION метров.
        """
        fig, ax = plt.subplots(figsize=(11, 11))

        # — фон поля —
        ax.add_patch(patches.Rectangle((0, 0), self.config.AREA_SIZE, self.config.AREA_SIZE,
                                       facecolor='#f7f9fc', edgecolor='black', linewidth=1.2))

        # — дороги —
        for road_type, coord in self.config.ROADS:
            half_w = self.config.ROAD_WIDTH / 2
            if road_type == 'h':
                ax.add_patch(patches.Rectangle((0, coord - half_w),
                                               self.config.AREA_SIZE, self.config.ROAD_WIDTH,
                                               color='gray', alpha=0.6, label='_road'))
                # пунктирная разметка по центру
                ax.plot([0, self.config.AREA_SIZE], [coord, coord],
                        color='white', linestyle='--', linewidth=1.5)
            else:
                ax.add_patch(patches.Rectangle((coord - half_w, 0),
                                               self.config.ROAD_WIDTH, self.config.AREA_SIZE,
                                               color='gray', alpha=0.6, label='_road'))
                ax.plot([coord, coord], [0, self.config.AREA_SIZE],
                        color='white', linestyle='--', linewidth=1.5)

        # — объекты —
        for i, (x, y) in enumerate(positions):
            obj_idx = placer.placed_objects[i]
            shape_type, dims = placer.get_object_shape(obj_idx)
            if shape_type == 'circle':
                ax.add_patch(patches.Circle((x, y), dims, facecolor='#4a90e2',
                                            edgecolor='black', alpha=0.75, linewidth=1.5))
            else:
                l, w = dims
                ax.add_patch(patches.Rectangle((x - w / 2, y - l / 2), w, l,
                                               facecolor='#7ed321',
                                               edgecolor='black', alpha=0.75, linewidth=1.5))
            ax.text(x, y, str(obj_idx + 1), color='white', ha='center', va='center',
                    fontweight='bold', fontsize=10)

        # — дискретная сетка —
        if show_grid_lines:
            step = max(1, int(self.config.GRID_RESOLUTION) * 5)
            ax.set_xticks(np.arange(0, self.config.AREA_SIZE + 1, step))
            ax.set_yticks(np.arange(0, self.config.AREA_SIZE + 1, step))
            ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)

        ax.set_xlim(0, self.config.AREA_SIZE)
        ax.set_ylim(self.config.AREA_SIZE, 0)            # инверсия Y, как в матрице
        ax.set_aspect('equal')

        # — заголовок —
        if quality_breakdown is not None:
            total_pen = (quality_breakdown['penalty_road']
                         + quality_breakdown['penalty_fire']
                         + quality_breakdown['penalty_collision'])
            total_bon = (quality_breakdown['bonus_road']
                         + quality_breakdown['bonus_compact']
                         + quality_breakdown['bonus_tech'])
            title = (f"Размещение | Итог: {quality_breakdown['total']:.1f} | "
                     f"Штрафы: -{total_pen:.1f} | "
                     f"Бонусы: +{total_bon:.1f}")
        else:
            title = "Размещение объектов"
        ax.set_title(title, fontsize=13, fontweight='bold')
        ax.set_xlabel("X, м")
        ax.set_ylabel("Y, м")

        # — легенда —
        legend = [
            patches.Patch(facecolor='gray', alpha=0.6, label='Дорога'),
            patches.Patch(facecolor='#4a90e2', alpha=0.75, label='Круглый объект'),
            patches.Patch(facecolor='#7ed321', alpha=0.75, label='Прямоугольный объект'),
        ]
        ax.legend(handles=legend, loc='upper right', framealpha=0.9)

        plt.tight_layout()
        plt.savefig(save_path, dpi=150)
        print(f"График сохранён: {save_path}")
        if show:
            plt.show()
        plt.close(fig)

    # ------------------------------------------------------------------ #

    def plot_training_history(self, losses, save_path='training_history.png', show=True):
        if not losses:
            print("Нет данных истории обучения.")
            return
        plt.figure(figsize=(10, 6))
        plt.plot(losses, linewidth=2, color='#4a90e2', label='Training Loss')

        if len(losses) > 10:
            try:
                from scipy.ndimage import gaussian_filter1d
                smoothed = gaussian_filter1d(losses, sigma=2)
                plt.plot(smoothed, linewidth=2, color='#d0021b', alpha=0.8, label='Smoothed')
            except ImportError:
                pass

        plt.xlabel('Epoch')
        plt.ylabel('MSE Loss')
        plt.title('История обучения RNN', fontweight='bold')
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(save_path, dpi=150)
        if show:
            plt.show()
        plt.close()

    # ------------------------------------------------------------------ #

    def print_statistics(self, placer, positions, breakdown):
        """Текстовая статистика размещения."""
        print("\n" + "=" * 60)
        print("СТАТИСТИКА РАЗМЕЩЕНИЯ ОБЪЕКТОВ")
        print("=" * 60)
        print(f"Всего размещено: {len(positions)} из {placer.num_objects}")
        if not positions:
            return

        print("\nМетрика качества:")
        print(f"  Штраф (дороги):           -{breakdown['penalty_road']:.1f}")
        print(f"  Штраф (противопожарный):  -{breakdown['penalty_fire']:.1f}")
        print(f"  Штраф (коллизии):         -{breakdown['penalty_collision']:.1f}")
        print(f"  Бонус (близость к дороге):+{breakdown['bonus_road']:.1f}")
        print(f"  Бонус (компактность):     +{breakdown['bonus_compact']:.1f}")
        print(f"  Бонус (тех. связи):       +{breakdown['bonus_tech']:.1f}")
        print(f"  ИТОГО:                     {breakdown['total']:.1f}")

        print("\nКоординаты объектов:")
        print("  №  | obj idx |   X |   Y | форма")
        for i, (x, y) in enumerate(positions):
            obj_idx = placer.placed_objects[i]
            shape_type, _ = placer.get_object_shape(obj_idx)
            print(f"  {i + 1:>2d} |   {obj_idx + 1:>2d}    | {x:>3d} | {y:>3d} | {shape_type}")
