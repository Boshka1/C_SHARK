import torch
import torch.nn as nn


class PlacementRNN(nn.Module):
    """Рекуррентная нейросеть (LSTM) для последовательного размещения объектов.

    Особенности:
      • На вход подаётся последовательность признаков длиной T (T = число объектов).
      • Каждый временной шаг возвращает 2 нормированные координаты (x, y) для
        очередного объекта.
      • Скрытое состояние LSTM сохраняется между шагами — модель «помнит»
        уже размещённые объекты (это и есть рекуррентная связь).
    """

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.hidden_size = config.HIDDEN_SIZE
        self.num_layers = config.NUM_LAYERS

        self.lstm = nn.LSTM(
            input_size=config.INPUT_SIZE,
            hidden_size=config.HIDDEN_SIZE,
            num_layers=config.NUM_LAYERS,
            batch_first=True,
            dropout=0.2 if config.NUM_LAYERS > 1 else 0.0
        )
        self.head = nn.Sequential(
            nn.Linear(config.HIDDEN_SIZE, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, config.OUTPUT_SIZE),
            nn.Sigmoid()       # выход в (0, 1) — нормированные координаты
        )

    def forward(self, x, hidden=None, return_sequence=False):
        """
        Args:
            x: (B, T, INPUT_SIZE) — батч последовательностей
            hidden: предыдущее (h, c) или None
            return_sequence:
                False — вернуть только последний шаг (B, 2);
                True  — вернуть все шаги (B, T, 2). Используется при обучении.
        """
        lstm_out, hidden_out = self.lstm(x, hidden)
        if return_sequence:
            return self.head(lstm_out), hidden_out
        return self.head(lstm_out[:, -1, :]), hidden_out

    def init_hidden(self, batch_size, device=None):
        device = device or next(self.parameters()).device
        h = torch.zeros(self.num_layers, batch_size, self.hidden_size, device=device)
        c = torch.zeros(self.num_layers, batch_size, self.hidden_size, device=device)
        return (h, c)
