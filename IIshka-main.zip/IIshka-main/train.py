import os
import pickle

import torch
import torch.optim as optim

from config import Config


class Trainer:
    """Обучение PlacementRNN на полных траекториях размещения."""

    def __init__(self, config, model, placer):
        self.config = config
        self.model = model
        self.placer = placer
        self.criterion = torch.nn.MSELoss()
        self.optimizer = optim.Adam(model.parameters(), lr=config.LEARNING_RATE)
        self.train_losses = []

    # ------------------------------------------------------------------ #

    def train(self, progress_callback=None):
        """Обучение модели.

        Args:
            progress_callback(epoch, total_epochs, loss) — необязательная функция,
                чтобы GUI мог отрисовывать прогресс.
        """
        print("Создание обучающих траекторий...")
        sequences, targets = self.placer.create_training_data(self.config.NUM_SAMPLES)
        if not sequences:
            print("Не удалось сгенерировать обучающие данные.")
            return self.train_losses
        print(f"Создано {len(sequences)} траекторий (среднее число шагов: "
              f"{sum(len(s) for s in sequences) / len(sequences):.1f})")

        # Группируем последовательности по длине, чтобы можно было «складывать» в батч
        # без паддингов.
        buckets = {}
        for seq, tgt in zip(sequences, targets):
            buckets.setdefault(len(seq), []).append((seq, tgt))

        device = self.config.DEVICE
        self.model.to(device)
        print(f"Начало обучения на {device}...")

        for epoch in range(self.config.EPOCHS):
            self.model.train()
            total_loss, n_batches = 0.0, 0

            for length, items in buckets.items():
                # Перемешиваем внутри бакета
                idx = torch.randperm(len(items)).tolist()
                items = [items[i] for i in idx]

                for start in range(0, len(items), self.config.BATCH_SIZE):
                    chunk = items[start:start + self.config.BATCH_SIZE]
                    batch_x = torch.stack([c[0] for c in chunk]).to(device)
                    batch_y = torch.stack([c[1] for c in chunk]).to(device)

                    self.optimizer.zero_grad()
                    pred, _ = self.model(batch_x, return_sequence=True)
                    loss = self.criterion(pred, batch_y)
                    loss.backward()
                    self.optimizer.step()
                    total_loss += loss.item()
                    n_batches += 1

            avg_loss = total_loss / max(1, n_batches)
            self.train_losses.append(avg_loss)

            if progress_callback:
                progress_callback(epoch + 1, self.config.EPOCHS, avg_loss)
            if (epoch + 1) % 10 == 0:
                print(f'Epoch [{epoch + 1}/{self.config.EPOCHS}], Loss: {avg_loss:.6f}')

        print("Обучение завершено!")
        return self.train_losses

    # ------------------------------------------------------------------ #

    def save_model(self, path=None):
        if path is None:
            path = self.config.MODEL_SAVE_PATH
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'config': self.config,
            'train_losses': self.train_losses
        }, path)
        print(f"Модель сохранена в {path}")

    def load_model(self, path):
        try:
            torch.serialization.add_safe_globals([Config])
            checkpoint = torch.load(path, map_location=self.config.DEVICE, weights_only=True)
        except (AttributeError, TypeError, pickle.UnpicklingError):
            print("Не удалось загрузить с weights_only=True — пробуем без ограничений...")
            checkpoint = torch.load(path, map_location=self.config.DEVICE, weights_only=False)

        self.model.load_state_dict(checkpoint['model_state_dict'])
        try:
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        except Exception:
            pass
        self.train_losses = checkpoint.get('train_losses', [])
        print(f"Модель загружена из {path}")
