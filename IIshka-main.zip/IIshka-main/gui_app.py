"""
Графический интерфейс «AI Object Placer».

Возможности:
  • вкладка «Объекты»    — добавить/редактировать/удалить объекты,
                           переключить форму (круг / прямоугольник);
  • вкладка «Дороги»     — добавить/удалить горизонтальные и вертикальные дороги;
  • вкладка «Параметры»  — размер поля, ширина дорог, минимальное расстояние
                           до дороги, штрафы и бонусы;
  • статус ИИ (обучена / не обучена), кнопки обучить / запустить;
  • визуализация с дискретной сеткой и легендой;
  • панель метрик с разбивкой по штрафам и бонусам.
"""

import math
import os
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import torch
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg,
                                                NavigationToolbar2Tk)

from config import Config
from data_loader import DataLoader
from models import PlacementRNN
from placer import ObjectPlacer
from predict import Predictor
from train import Trainer


# ---------------------------------------------------------------------------
# Цветовая палитра
# ---------------------------------------------------------------------------
BG_MAIN = "#f4f6f9"
BG_CARD = "#ffffff"
ACCENT = "#4a90e2"
ACCENT_DARK = "#2c5d99"
SUCCESS = "#7ed321"
DANGER = "#d0021b"
TEXT_MUTED = "#6b7280"


# ===========================================================================
# Главное окно
# ===========================================================================
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AI Object Placer — интеллектуальное распределение объектов")
        self.geometry("1500x900")
        self.minsize(1200, 760)
        self.configure(bg=BG_MAIN)

        self.config = Config()
        self.objects = []            # [{'shape', 'l', 'w', 'r'}]  ← один словарь на объект
        self.roads = list(self.config.ROADS)
        self.distances_matrix = None  # tensor (N_TOTAL, N_TOTAL)
        self.sequence_matrix = None
        self.category_labels = None   # порядок строк в матрицах
        self.placer = None
        self.model = None

        self._init_style()
        self._init_ui()
        self._load_from_excel(silent=True)
        self._refresh_objects_tree()
        self._refresh_roads_tree()
        self.after(150, self._update_model_status)
        self._redraw_canvas()

    # ----------------------------------------------------------------- #
    # Стили ttk
    # ----------------------------------------------------------------- #
    def _init_style(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except Exception:
            pass
        st.configure("Card.TFrame", background=BG_CARD)
        st.configure("Main.TFrame", background=BG_MAIN)
        st.configure("Title.TLabel", background=BG_CARD,
                     font=("Segoe UI", 13, "bold"), foreground=ACCENT_DARK)
        st.configure("SubTitle.TLabel", background=BG_CARD,
                     font=("Segoe UI", 10, "bold"))
        st.configure("Card.TLabel", background=BG_CARD, font=("Segoe UI", 10))
        st.configure("Muted.TLabel", background=BG_CARD, foreground=TEXT_MUTED,
                     font=("Segoe UI", 9))
        st.configure("Status.TLabel", background=BG_CARD,
                     font=("Segoe UI", 9, "italic"), foreground=ACCENT_DARK)
        st.configure("Big.TButton", padding=8, font=("Segoe UI", 10, "bold"))
        st.configure("TNotebook", background=BG_MAIN)
        st.configure("TNotebook.Tab", padding=(12, 6), font=("Segoe UI", 10))
        st.configure("Treeview", rowheight=24, font=("Segoe UI", 10))
        st.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

    # ----------------------------------------------------------------- #
    # Layout
    # ----------------------------------------------------------------- #
    def _init_ui(self):
        # Левая колонка — управление
        left = ttk.Frame(self, style="Main.TFrame", padding=10)
        left.pack(side=tk.LEFT, fill=tk.Y)

        # Правая колонка — визуализация + метрики
        right = ttk.Frame(self, style="Main.TFrame", padding=10)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self._build_left_panel(left)
        self._build_right_panel(right)

    # ----------------------------------------------------------------- #

    def _build_left_panel(self, parent):
        # — заголовок —
        title_card = ttk.Frame(parent, style="Card.TFrame", padding=10)
        title_card.pack(fill=tk.X, pady=(0, 8))
        ttk.Label(title_card, text="AI Object Placer", style="Title.TLabel").pack(anchor="w")
        ttk.Label(title_card, style="Muted.TLabel",
                  text="RNN-распределение объектов с учётом\n"
                       "противопожарных норм и дорог").pack(anchor="w")

        # — статус модели —
        status_card = ttk.Frame(parent, style="Card.TFrame", padding=10)
        status_card.pack(fill=tk.X, pady=(0, 8))
        self.model_status_var = tk.StringVar(value="Статус ИИ: проверка...")
        ttk.Label(status_card, textvariable=self.model_status_var,
                  style="Status.TLabel").pack(anchor="w")

        # — Notebook (вкладки) —
        nb = ttk.Notebook(parent, width=420, height=470)
        nb.pack(fill=tk.BOTH, expand=False, pady=(0, 8))

        self._build_objects_tab(nb)
        self._build_roads_tab(nb)
        self._build_params_tab(nb)

        # — кнопки действий —
        actions = ttk.Frame(parent, style="Card.TFrame", padding=10)
        actions.pack(fill=tk.X, pady=(0, 8))
        ttk.Label(actions, text="Действия", style="SubTitle.TLabel").pack(anchor="w")

        btn_row = ttk.Frame(actions, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=4)
        ttk.Button(btn_row, text="Обучить ИИ", style="Big.TButton",
                   command=self._start_training).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(btn_row, text="Запустить размещение", style="Big.TButton",
                   command=self._start_inference).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        btn_row2 = ttk.Frame(actions, style="Card.TFrame")
        btn_row2.pack(fill=tk.X, pady=4)
        ttk.Button(btn_row2, text="↻ Перезагрузить Excel",
                   command=self._reload_excel).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(btn_row2, text="🗑 Очистить поле",
                   command=self._clear_placement).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        self.progress = ttk.Progressbar(actions, orient=tk.HORIZONTAL, mode="determinate")
        self.progress.pack(fill=tk.X, pady=(8, 2))

    # ----------------------------------------------------------------- #

    def _build_objects_tab(self, nb):
        tab = ttk.Frame(nb, style="Card.TFrame", padding=8)
        nb.add(tab, text="Объекты")

        ttk.Label(tab, text="Список объектов для размещения",
                  style="SubTitle.TLabel").pack(anchor="w", pady=(0, 4))

        cols = ("idx", "shape", "l", "w", "r")
        self.obj_tree = ttk.Treeview(tab, columns=cols, show="headings", height=10)
        for c, w in zip(cols, (40, 130, 70, 70, 70)):
            self.obj_tree.column(c, width=w, anchor="center")
        self.obj_tree.heading("idx", text="№")
        self.obj_tree.heading("shape", text="Форма")
        self.obj_tree.heading("l", text="Длина")
        self.obj_tree.heading("w", text="Ширина")
        self.obj_tree.heading("r", text="Радиус")
        self.obj_tree.pack(fill=tk.BOTH, expand=True, pady=4)
        self.obj_tree.bind("<<TreeviewSelect>>", self._on_object_select)

        # форма добавления
        form = ttk.Frame(tab, style="Card.TFrame", padding=4)
        form.pack(fill=tk.X, pady=(8, 0))
        ttk.Label(form, text="Форма:", style="Card.TLabel").grid(row=0, column=0, sticky="w")
        self.obj_shape_var = tk.StringVar(value="rectangle")
        ttk.Combobox(form, textvariable=self.obj_shape_var, state="readonly",
                     values=["rectangle", "circle"], width=12).grid(row=0, column=1, padx=4)

        ttk.Label(form, text="L:", style="Card.TLabel").grid(row=0, column=2, padx=(8, 0))
        self.obj_l_var = tk.StringVar(value="10")
        ttk.Entry(form, textvariable=self.obj_l_var, width=6).grid(row=0, column=3)

        ttk.Label(form, text="W:", style="Card.TLabel").grid(row=0, column=4, padx=(8, 0))
        self.obj_w_var = tk.StringVar(value="10")
        ttk.Entry(form, textvariable=self.obj_w_var, width=6).grid(row=0, column=5)

        ttk.Label(form, text="R:", style="Card.TLabel").grid(row=0, column=6, padx=(8, 0))
        self.obj_r_var = tk.StringVar(value="5")
        ttk.Entry(form, textvariable=self.obj_r_var, width=6).grid(row=0, column=7)

        btn_row = ttk.Frame(tab, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=6)
        ttk.Button(btn_row, text="➕ Добавить", command=self._add_object).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="✎ Применить", command=self._edit_object).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="✖ Удалить",  command=self._delete_object).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="↺ Из Excel", command=self._reload_excel).pack(side=tk.RIGHT, padx=2)

    # ----------------------------------------------------------------- #

    def _build_roads_tab(self, nb):
        tab = ttk.Frame(nb, style="Card.TFrame", padding=8)
        nb.add(tab, text="Дороги")

        ttk.Label(tab, text="Список дорог на участке",
                  style="SubTitle.TLabel").pack(anchor="w", pady=(0, 4))

        cols = ("idx", "type", "coord")
        self.road_tree = ttk.Treeview(tab, columns=cols, show="headings", height=8)
        self.road_tree.column("idx", width=40, anchor="center")
        self.road_tree.column("type", width=140, anchor="center")
        self.road_tree.column("coord", width=120, anchor="center")
        self.road_tree.heading("idx", text="№")
        self.road_tree.heading("type", text="Тип")
        self.road_tree.heading("coord", text="Координата, м")
        self.road_tree.pack(fill=tk.BOTH, expand=True, pady=4)

        form = ttk.Frame(tab, style="Card.TFrame")
        form.pack(fill=tk.X, pady=6)
        ttk.Label(form, text="Тип:", style="Card.TLabel").grid(row=0, column=0, sticky="w")
        self.road_type_var = tk.StringVar(value="h")
        ttk.Combobox(form, textvariable=self.road_type_var, state="readonly",
                     values=["h", "v"], width=4).grid(row=0, column=1, padx=4)
        ttk.Label(form, text="Координата (м):", style="Card.TLabel").grid(row=0, column=2, padx=(8, 0))
        self.road_coord_var = tk.StringVar(value="50")
        ttk.Entry(form, textvariable=self.road_coord_var, width=8).grid(row=0, column=3)

        btn_row = ttk.Frame(tab, style="Card.TFrame")
        btn_row.pack(fill=tk.X, pady=4)
        ttk.Button(btn_row, text="➕ Добавить дорогу", command=self._add_road).pack(side=tk.LEFT, padx=2)
        ttk.Button(btn_row, text="✖ Удалить дорогу",  command=self._delete_road).pack(side=tk.LEFT, padx=2)

        ttk.Label(tab, style="Muted.TLabel",
                  text="h — горизонтальная (Y=coord)\nv — вертикальная   (X=coord)").pack(anchor="w", pady=(8, 0))

    # ----------------------------------------------------------------- #

    def _build_params_tab(self, nb):
        tab = ttk.Frame(nb, style="Card.TFrame", padding=8)
        nb.add(tab, text="Параметры")

        ttk.Label(tab, text="Параметры участка и метрики",
                  style="SubTitle.TLabel").pack(anchor="w", pady=(0, 4))

        grid = ttk.Frame(tab, style="Card.TFrame")
        grid.pack(fill=tk.X, pady=4)

        def make_row(parent, label, var, row):
            ttk.Label(parent, text=label, style="Card.TLabel").grid(row=row, column=0, sticky="w", pady=2)
            ttk.Entry(parent, textvariable=var, width=10).grid(row=row, column=1, sticky="w", padx=4, pady=2)

        self.area_size_var = tk.StringVar(value=str(self.config.AREA_SIZE))
        self.road_width_var = tk.StringVar(value=str(self.config.ROAD_WIDTH))
        self.min_dist_road_var = tk.StringVar(value=str(self.config.MIN_DIST_TO_ROAD))
        self.grid_res_var = tk.StringVar(value=str(self.config.GRID_RESOLUTION))

        make_row(grid, "Размер поля, м:", self.area_size_var, 0)
        make_row(grid, "Ширина дороги, м:", self.road_width_var, 1)
        make_row(grid, "Мин. дистанция до дороги, м:", self.min_dist_road_var, 2)
        make_row(grid, "Шаг сетки, м:", self.grid_res_var, 3)

        ttk.Separator(tab, orient="horizontal").pack(fill=tk.X, pady=8)

        ttk.Label(tab, text="Штрафы и бонусы метрики",
                  style="SubTitle.TLabel").pack(anchor="w")
        pgrid = ttk.Frame(tab, style="Card.TFrame")
        pgrid.pack(fill=tk.X, pady=4)

        self.pen_road_var = tk.StringVar(value=str(self.config.PENALTY_ROAD_VIOLATION))
        self.pen_fire_var = tk.StringVar(value=str(self.config.PENALTY_FIRE_SAFETY))
        self.pen_coll_var = tk.StringVar(value=str(self.config.PENALTY_COLLISION))
        self.bon_road_var = tk.StringVar(value=str(self.config.BONUS_ROAD_PROXIMITY))
        self.bon_comp_var = tk.StringVar(value=str(self.config.BONUS_COMPACTNESS))
        self.bon_tech_var = tk.StringVar(value=str(self.config.BONUS_TECH_LINK))

        make_row(pgrid, "Штраф: дороги:",      self.pen_road_var, 0)
        make_row(pgrid, "Штраф: пож. безопасность:", self.pen_fire_var, 1)
        make_row(pgrid, "Штраф: коллизии:",    self.pen_coll_var, 2)
        make_row(pgrid, "Бонус: близость к дороге:", self.bon_road_var, 3)
        make_row(pgrid, "Бонус: компактность:", self.bon_comp_var, 4)
        make_row(pgrid, "Бонус: тех. связи:",  self.bon_tech_var, 5)

        ttk.Button(tab, text="Применить параметры", command=self._apply_params,
                   style="Big.TButton").pack(fill=tk.X, pady=8)

        # Чекбокс: отображать дискретную сетку
        self.show_grid_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(tab, text="Показывать дискретную сетку на графике",
                        variable=self.show_grid_var,
                        command=self._redraw_canvas).pack(anchor="w", pady=4)

    # ----------------------------------------------------------------- #

    def _build_right_panel(self, parent):
        # — холст с графиком —
        plot_card = ttk.Frame(parent, style="Card.TFrame", padding=6)
        plot_card.pack(fill=tk.BOTH, expand=True)

        self.fig, self.ax = plt.subplots(figsize=(8, 8))
        self.fig.patch.set_facecolor(BG_CARD)
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_card)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # — нижняя панель: метрики + лог —
        bottom = ttk.Frame(parent, style="Main.TFrame")
        bottom.pack(fill=tk.X, pady=(8, 0))

        metrics = ttk.Frame(bottom, style="Card.TFrame", padding=8)
        metrics.pack(side=tk.LEFT, fill=tk.Y)
        ttk.Label(metrics, text="Метрика качества", style="SubTitle.TLabel").pack(anchor="w")

        self.metric_vars = {
            "penalty_road":      tk.StringVar(value="0.0"),
            "penalty_fire":      tk.StringVar(value="0.0"),
            "penalty_collision": tk.StringVar(value="0.0"),
            "bonus_road":        tk.StringVar(value="0.0"),
            "bonus_compact":     tk.StringVar(value="0.0"),
            "bonus_tech":        tk.StringVar(value="0.0"),
            "total":             tk.StringVar(value="0.0"),
        }
        rows = [
            ("Штраф: дороги",            "penalty_road",      DANGER),
            ("Штраф: пож. безопасность", "penalty_fire",      DANGER),
            ("Штраф: коллизии",          "penalty_collision", DANGER),
            ("Бонус: близость к дороге", "bonus_road",        SUCCESS),
            ("Бонус: компактность",      "bonus_compact",     SUCCESS),
            ("Бонус: тех. связи",        "bonus_tech",        SUCCESS),
            ("ИТОГО",                    "total",             ACCENT_DARK),
        ]
        for label, key, color in rows:
            row = ttk.Frame(metrics, style="Card.TFrame")
            row.pack(fill=tk.X, pady=1)
            ttk.Label(row, text=label, style="Card.TLabel", width=24).pack(side=tk.LEFT)
            lbl = tk.Label(row, textvariable=self.metric_vars[key], bg=BG_CARD,
                           fg=color, font=("Segoe UI", 10, "bold"), width=10, anchor="e")
            lbl.pack(side=tk.LEFT)

        log_card = ttk.Frame(bottom, style="Card.TFrame", padding=8)
        log_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8, 0))
        ttk.Label(log_card, text="Лог выполнения", style="SubTitle.TLabel").pack(anchor="w")
        self.log_text = tk.Text(log_card, height=10, wrap="word",
                                font=("Consolas", 9), bg=BG_CARD)
        self.log_text.pack(fill=tk.BOTH, expand=True)

    # ================================================================= #
    # Логика
    # ================================================================= #

    # ---- логирование ---- #
    def _log(self, msg):
        self.log_text.insert(tk.END, msg + "\n")
        self.log_text.see(tk.END)
        self.update_idletasks()

    # ---- статус модели ---- #
    def _update_model_status(self):
        if os.path.exists(self.config.MODEL_SAVE_PATH):
            try:
                ckpt = torch.load(self.config.MODEL_SAVE_PATH,
                                  map_location=self.config.DEVICE, weights_only=False)
                saved = ckpt.get('config')
                if saved is not None:
                    self.model_status_var.set(
                        f"Статус ИИ: ОБУЧЕНА  (поле {saved.AREA_SIZE} м, "
                        f"мин. дист. до дороги {saved.MIN_DIST_TO_ROAD} м)")
                else:
                    self.model_status_var.set("Статус ИИ: ОБУЧЕНА (старый формат)")
            except Exception:
                self.model_status_var.set("Статус ИИ: ОШИБКА чтения модели")
        else:
            self.model_status_var.set("Статус ИИ: НЕ ОБУЧЕНА — будут случайные веса")

    # ---- загрузка из Excel ---- #
    def _load_from_excel(self, silent=False):
        try:
            dl = DataLoader(self.config)
            distances, sequence, characteristics = dl.load_data()
            self.distances_matrix = distances
            self.sequence_matrix = sequence
            self.objects = []
            for i in range(characteristics.shape[0]):
                l, w, r = (characteristics[i, 0].item(),
                           characteristics[i, 1].item(),
                           characteristics[i, 2].item())
                if r > 0:
                    self.objects.append({"shape": "circle", "l": 0.0, "w": 0.0, "r": r})
                else:
                    self.objects.append({"shape": "rectangle", "l": l, "w": w, "r": 0.0})
            if not silent:
                messagebox.showinfo("Данные", f"Загружено объектов: {len(self.objects)}")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось загрузить Excel:\n{e}")

    def _reload_excel(self):
        self._load_from_excel()
        self._refresh_objects_tree()
        self._clear_placement()

    # ---- объекты ---- #
    def _refresh_objects_tree(self):
        self.obj_tree.delete(*self.obj_tree.get_children())
        for i, obj in enumerate(self.objects):
            self.obj_tree.insert(
                "", "end", values=(
                    i + 1, obj["shape"],
                    f"{obj['l']:g}", f"{obj['w']:g}", f"{obj['r']:g}"
                )
            )

    def _on_object_select(self, _event=None):
        sel = self.obj_tree.selection()
        if not sel:
            return
        idx = self.obj_tree.index(sel[0])
        obj = self.objects[idx]
        self.obj_shape_var.set(obj["shape"])
        self.obj_l_var.set(f"{obj['l']:g}")
        self.obj_w_var.set(f"{obj['w']:g}")
        self.obj_r_var.set(f"{obj['r']:g}")

    def _read_object_form(self):
        try:
            shape = self.obj_shape_var.get()
            l = float(self.obj_l_var.get() or 0)
            w = float(self.obj_w_var.get() or 0)
            r = float(self.obj_r_var.get() or 0)
            if shape == "circle":
                if r <= 0:
                    raise ValueError("Для круга нужен радиус > 0")
                return {"shape": "circle", "l": 0.0, "w": 0.0, "r": r}
            else:
                if l <= 0 or w <= 0:
                    raise ValueError("Для прямоугольника нужны L > 0 и W > 0")
                return {"shape": "rectangle", "l": l, "w": w, "r": 0.0}
        except Exception as e:
            messagebox.showerror("Ошибка ввода", str(e))
            return None

    def _add_object(self):
        obj = self._read_object_form()
        if obj is None:
            return
        self.objects.append(obj)
        self._refresh_objects_tree()
        self._log(f"+ объект {len(self.objects)}: {obj['shape']}")

    def _edit_object(self):
        sel = self.obj_tree.selection()
        if not sel:
            messagebox.showinfo("Подсказка", "Выберите объект в списке.")
            return
        obj = self._read_object_form()
        if obj is None:
            return
        idx = self.obj_tree.index(sel[0])
        self.objects[idx] = obj
        self._refresh_objects_tree()
        self.obj_tree.selection_set(self.obj_tree.get_children()[idx])

    def _delete_object(self):
        sel = self.obj_tree.selection()
        if not sel:
            return
        idx = self.obj_tree.index(sel[0])
        self.objects.pop(idx)
        self._refresh_objects_tree()

    # ---- дороги ---- #
    def _refresh_roads_tree(self):
        self.road_tree.delete(*self.road_tree.get_children())
        for i, (t, coord) in enumerate(self.roads):
            label = "горизонтальная (h)" if t == "h" else "вертикальная (v)"
            self.road_tree.insert("", "end", values=(i + 1, label, coord))

    def _add_road(self):
        try:
            t = self.road_type_var.get()
            c = int(float(self.road_coord_var.get()))
        except Exception:
            messagebox.showerror("Ошибка", "Введите целое значение координаты дороги.")
            return
        self.roads.append((t, c))
        self._refresh_roads_tree()
        self._redraw_canvas()

    def _delete_road(self):
        sel = self.road_tree.selection()
        if not sel:
            return
        idx = self.road_tree.index(sel[0])
        self.roads.pop(idx)
        self._refresh_roads_tree()
        self._redraw_canvas()

    # ---- параметры ---- #
    def _apply_params(self):
        try:
            self.config.AREA_SIZE = int(self.area_size_var.get())
            self.config.ROAD_WIDTH = int(self.road_width_var.get())
            self.config.MIN_DIST_TO_ROAD = int(self.min_dist_road_var.get())
            self.config.GRID_RESOLUTION = int(self.grid_res_var.get())
            self.config.PENALTY_ROAD_VIOLATION = float(self.pen_road_var.get())
            self.config.PENALTY_FIRE_SAFETY    = float(self.pen_fire_var.get())
            self.config.PENALTY_COLLISION      = float(self.pen_coll_var.get())
            self.config.BONUS_ROAD_PROXIMITY   = float(self.bon_road_var.get())
            self.config.BONUS_COMPACTNESS      = float(self.bon_comp_var.get())
            self.config.BONUS_TECH_LINK        = float(self.bon_tech_var.get())
            self._log("Параметры применены.")
            self._redraw_canvas()
        except Exception as e:
            messagebox.showerror("Ошибка параметров", str(e))

    # ---- очистка ---- #
    def _clear_placement(self):
        self.placer = None
        for k in self.metric_vars:
            self.metric_vars[k].set("0.0")
        self._redraw_canvas()
        self._log("Поле очищено.")

    # ================================================================= #
    # Подготовка placer для GUI-объектов
    # ================================================================= #

    def _build_placer_from_gui(self):
        """Собираем ObjectPlacer из текущего GUI-состояния."""
        if not self.objects:
            raise ValueError("Сначала добавьте хотя бы один объект.")
        if self.distances_matrix is None or self.sequence_matrix is None:
            raise ValueError("Сначала загрузите Excel-данные.")

        # Тензор габаритов
        chars = torch.tensor(
            [[o['l'], o['w'], o['r']] for o in self.objects], dtype=torch.float32
        )

        # Подматрица расстояний: если в GUI ровно столько же объектов, сколько в Excel,
        # используем матрицу как есть. Иначе клонируем строки/столбцы Excel и
        # дополняем — берём средние значения, чтобы новые объекты тоже учитывались.
        N = len(self.objects)
        D_excel = self.distances_matrix
        S_excel = self.sequence_matrix

        n_excel = D_excel.shape[0]
        D = torch.zeros((N, N))
        S = torch.zeros((N, N))
        for i in range(N):
            ei = i % n_excel
            for j in range(N):
                ej = j % n_excel
                D[i, j] = D_excel[ei, ej]
                S[i, j] = S_excel[ei, ej]

        self.config.ROADS = list(self.roads)
        self.config.NUM_OBJECTS = N
        self.config.characteristics_tensor = chars
        self.config.sequence_data = S

        placer = ObjectPlacer(self.config, D, S, chars)
        return placer

    # ================================================================= #
    # Обучение и предсказание
    # ================================================================= #

    def _start_training(self):
        try:
            self._apply_params()
            placer = self._build_placer_from_gui()
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))
            return

        self.model = PlacementRNN(self.config).to(self.config.DEVICE)
        trainer = Trainer(self.config, self.model, placer)

        self._log("Начало обучения...")
        self.progress["value"] = 0
        self.progress["maximum"] = self.config.EPOCHS

        def progress_cb(epoch, total, loss):
            self.progress["value"] = epoch
            if epoch % 5 == 0 or epoch == total:
                self._log(f"  Epoch {epoch}/{total}: loss = {loss:.6f}")
            self.update_idletasks()

        def task():
            try:
                trainer.train(progress_callback=progress_cb)
                trainer.save_model()
                self._log("Обучение завершено и модель сохранена.")
                self._update_model_status()
                messagebox.showinfo("Готово", "Модель обучена и сохранена.")
            except Exception as e:
                self._log(f"Ошибка обучения: {e}")
                messagebox.showerror("Ошибка обучения", str(e))

        # Запускаем в отдельном потоке, чтобы не блокировать UI
        threading.Thread(target=task, daemon=True).start()

    # ----------------------------------------------------------------- #

    def _start_inference(self):
        try:
            self._apply_params()
            self.placer = self._build_placer_from_gui()
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))
            return

        # Загружаем сохранённую модель, если есть, иначе используем случайные веса
        self.model = PlacementRNN(self.config).to(self.config.DEVICE)
        if os.path.exists(self.config.MODEL_SAVE_PATH):
            try:
                ckpt = torch.load(self.config.MODEL_SAVE_PATH,
                                  map_location=self.config.DEVICE, weights_only=False)
                # модель загружается только если размерности совпадают
                self.model.load_state_dict(ckpt['model_state_dict'])
                self._log("Веса модели загружены.")
            except Exception as e:
                self._log(f"Не удалось загрузить модель: {e}. Использую случайные веса.")
        else:
            self._log("Файл модели не найден — использую случайные веса.")

        predictor = Predictor(self.config, self.model, self.placer)
        self._log("Запуск пошагового размещения...")
        self.progress["value"] = 0
        self.progress["maximum"] = self.placer.num_objects

        step_counter = [0]

        def task():
            try:
                for step, positions, breakdown in predictor.place_all_objects_generator():
                    step_counter[0] += 1
                    self.progress["value"] = step_counter[0]
                    placed = (len(self.placer.placed_objects) > 0
                              and self.placer.placed_objects[-1] == step
                              and len(positions) == step_counter[0])
                    if placed:
                        self._log(f"  Объект {step + 1} → {positions[-1]}")
                    else:
                        self._log(f"  Объект {step + 1}: НЕТ места!")
                    self._update_metrics(breakdown)
                    self._draw_placement()
                self._log(f"Готово. Итог: {breakdown['total']:.2f}")
            except Exception as e:
                self._log(f"Ошибка размещения: {e}")
                messagebox.showerror("Ошибка", str(e))

        threading.Thread(target=task, daemon=True).start()

    # ----------------------------------------------------------------- #
    # Визуализация
    # ----------------------------------------------------------------- #

    def _update_metrics(self, breakdown):
        for k, v in breakdown.items():
            if k in self.metric_vars:
                sign = ""
                if k.startswith("penalty"):
                    sign = "-"
                elif k.startswith("bonus"):
                    sign = "+"
                self.metric_vars[k].set(f"{sign}{v:.1f}")

    def _redraw_canvas(self):
        """Перерисовка пустого поля с дорогами (без размещённых объектов)."""
        self._draw_placement(empty=True)

    def _draw_placement(self, empty=False):
        ax = self.ax
        ax.clear()
        ax.set_facecolor("#f7f9fc")

        area = self.config.AREA_SIZE

        # — границы поля —
        ax.add_patch(mpatches.Rectangle((0, 0), area, area,
                                        facecolor="none", edgecolor="black", linewidth=1.5))

        # — дороги —
        roads = self.placer.config.ROADS if (self.placer and not empty) else self.roads
        for r_type, coord in roads:
            hw = self.config.ROAD_WIDTH / 2
            if r_type == "h":
                ax.add_patch(mpatches.Rectangle((0, coord - hw), area, self.config.ROAD_WIDTH,
                                                color="gray", alpha=0.55))
                ax.plot([0, area], [coord, coord], color="white",
                        linestyle="--", linewidth=1.2)
            else:
                ax.add_patch(mpatches.Rectangle((coord - hw, 0), self.config.ROAD_WIDTH, area,
                                                color="gray", alpha=0.55))
                ax.plot([coord, coord], [0, area], color="white",
                        linestyle="--", linewidth=1.2)

        # — объекты —
        if not empty and self.placer is not None:
            for i, (x, y) in enumerate(self.placer.positions):
                obj_idx = self.placer.placed_objects[i]
                shape_type, dims = self.placer.get_object_shape(obj_idx)
                if shape_type == "circle":
                    ax.add_patch(mpatches.Circle((x, y), dims, facecolor="#4a90e2",
                                                  edgecolor="black", alpha=0.78, linewidth=1.3))
                else:
                    l, w = dims
                    ax.add_patch(mpatches.Rectangle((x - w / 2, y - l / 2), w, l,
                                                    facecolor="#7ed321",
                                                    edgecolor="black", alpha=0.78, linewidth=1.3))
                ax.text(x, y, str(obj_idx + 1), color="white",
                        ha="center", va="center", fontweight="bold", fontsize=10)

        # — дискретная сетка —
        if self.show_grid_var.get():
            step = max(1, self.config.GRID_RESOLUTION) * 5
            ax.set_xticks(np.arange(0, area + 1, step))
            ax.set_yticks(np.arange(0, area + 1, step))
            ax.grid(True, alpha=0.35, linestyle="--", linewidth=0.6)
        else:
            ax.set_xticks([0, area // 2, area])
            ax.set_yticks([0, area // 2, area])
            ax.grid(False)

        ax.set_xlim(0, area)
        ax.set_ylim(area, 0)
        ax.set_aspect("equal")
        ax.set_xlabel("X, м")
        ax.set_ylabel("Y, м")

        title = f"Сетка {area}×{area} м, шаг {self.config.GRID_RESOLUTION} м"
        if not empty and self.placer is not None:
            title += f"  |  объектов: {len(self.placer.positions)}/{self.placer.num_objects}"
        ax.set_title(title, fontsize=11, fontweight="bold", color=ACCENT_DARK)

        # — легенда —
        legend = [
            mpatches.Patch(facecolor="gray", alpha=0.55, label="Дорога"),
            mpatches.Patch(facecolor="#4a90e2", alpha=0.78, label="Круг"),
            mpatches.Patch(facecolor="#7ed321", alpha=0.78, label="Прямоугольник"),
        ]
        ax.legend(handles=legend, loc="upper right", framealpha=0.9, fontsize=9)

        self.canvas.draw()


# ===========================================================================
if __name__ == "__main__":
    app = App()
    app.mainloop()
