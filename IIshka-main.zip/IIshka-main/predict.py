import math
import os
import pickle
import random

import torch


class Predictor:
    """Последовательное предсказание позиций объектов с поддержкой
    скрытого состояния LSTM (это и делает сеть по-настоящему рекуррентной)."""

    def __init__(self, config, model, placer):
        self.config = config
        self.model = model
        self.placer = placer
        self.model.eval()

    # ------------------------------------------------------------------ #

    def _compute_placement_order(self):
        """Сначала размещаем самые «сложные» объекты — большие по площади
        и/или с большими требованиями к отступам."""
        difficulties = []
        for i in range(self.placer.num_objects):
            shape_type, dims = self.placer.get_object_shape(i)
            area = math.pi * dims * dims if shape_type == 'circle' else dims[0] * dims[1]
            if self.placer.num_objects > 1:
                avg_dist = sum(self.placer.distances[i, j].item()
                               for j in range(self.placer.num_objects) if j != i
                               ) / (self.placer.num_objects - 1)
            else:
                avg_dist = 0.0
            difficulties.append((i, area + avg_dist))
        difficulties.sort(key=lambda x: x[1], reverse=True)
        order = [d[0] for d in difficulties]
        print(f"Порядок размещения (по сложности): {[o + 1 for o in order]}")
        return order

    # ------------------------------------------------------------------ #

    def place_all_objects_generator(self, samples_per_step=800):
        """Пошаговое размещение объектов.

        На каждом шаге:
            1. Вычисляем признаки текущего объекта.
            2. Подаём их в LSTM, СОХРАНЯЯ скрытое состояние — это и делает
               сеть рекуррентной (вспоминает предыдущие шаги).
            3. Получаем предсказанную точку (target_x, target_y).
            4. Сэмплируем кандидатов (часть рядом с предсказанием, часть случайно)
               и выбираем ту, где метрика качества максимальна.

        Yields:
            (step, positions, quality_breakdown_dict)
        """
        self.placer.reset()
        print("\nЗапуск размещения...")

        order = self._compute_placement_order()
        hidden = None       # скрытое состояние LSTM, переносится между шагами

        with torch.no_grad():
            for step in order:
                features = self.placer.get_object_features(step).to(self.config.DEVICE)
                features = features.unsqueeze(0).unsqueeze(1)        # (1, 1, INPUT_SIZE)

                pred_pos, hidden = self.model(features, hidden=hidden)
                target_x = int(pred_pos[0, 0].item() * self.config.AREA_SIZE)
                target_y = int(pred_pos[0, 1].item() * self.config.AREA_SIZE)

                available = self.placer.get_available_positions()
                if not available:
                    print(f"Не осталось места для объекта {step + 1}!")
                    yield step, list(self.placer.positions), self.placer.calculate_quality_breakdown()
                    continue

                # — кандидаты возле предсказания RNN + случайные —
                nearby = [p for p in available
                          if math.hypot(p[0] - target_x, p[1] - target_y) < 30]
                half = samples_per_step // 2
                nearby_sample = random.sample(nearby, min(len(nearby), half)) if nearby else []
                random_sample = random.sample(available, min(len(available),
                                                              samples_per_step - len(nearby_sample)))
                candidates = list({*nearby_sample, *random_sample})

                best_pos, best_quality = None, -float('inf')
                for x, y in candidates:
                    if not self.placer.can_place(x, y, step):
                        continue
                    # «Примеряем» позицию и считаем качество
                    self.placer.positions.append((x, y))
                    self.placer.placed_objects.append(step)
                    q = self.placer.calculate_quality()
                    q -= 0.05 * math.hypot(x - target_x, y - target_y)
                    self.placer.positions.pop()
                    self.placer.placed_objects.pop()
                    if q > best_quality:
                        best_quality, best_pos = q, (x, y)

                # — если ничего не нашли в выборке, ищем по всем валидным точкам —
                if best_pos is None:
                    for x, y in available:
                        if not self.placer.can_place(x, y, step):
                            continue
                        self.placer.positions.append((x, y))
                        self.placer.placed_objects.append(step)
                        q = self.placer.calculate_quality()
                        self.placer.positions.pop()
                        self.placer.placed_objects.pop()
                        if q > best_quality:
                            best_quality, best_pos = q, (x, y)

                if best_pos is not None:
                    self.placer.place_object(best_pos, step)
                else:
                    print(f"Объект {step + 1}: нет ни одной валидной позиции.")

                yield step, list(self.placer.positions), self.placer.calculate_quality_breakdown()

        breakdown = self.placer.calculate_quality_breakdown()
        print(f"\nРазмещение завершено! Итоговое качество: {breakdown['total']:.2f}")

    # ------------------------------------------------------------------ #

    def place_all_objects(self):
        """Обёртка для совместимости со старым кодом."""
        for _ in self.place_all_objects_generator():
            pass
        return self.placer.grid, self.placer.positions

    def save_results(self, path=None):
        if path is None:
            path = self.config.RESULTS_PATH
        os.makedirs(os.path.dirname(path), exist_ok=True)
        results = {
            'grid': self.placer.grid,
            'positions': self.placer.positions,
            'placed_objects': self.placer.placed_objects,
            'quality_breakdown': self.placer.calculate_quality_breakdown(),
            'config': self.config
        }
        with open(path, 'wb') as f:
            pickle.dump(results, f)
        print(f"Results saved to {path}")
