"""Веб-версия интерфейса на Streamlit. Запускать командой:
    streamlit run app.py
"""

import os

import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st
import torch

from config import Config
from data_loader import DataLoader
from models import PlacementRNN
from placer import ObjectPlacer
from predict import Predictor


st.set_page_config(page_title="AI Object Placer", layout="wide")
st.title("🏗️ Интеллектуальное распределение объектов на плоскости")
st.markdown("""
Система на базе **рекуррентной нейросети (LSTM)** для автоматического размещения
промышленных объектов с учётом:

* 🔥 противопожарной безопасности (минимальные расстояния из Excel-таблицы);
* 🛣️ обязательного отступа от дороги (по умолчанию 5 м);
* 📐 геометрии (круги и прямоугольники);
* 🔗 технологических связей между объектами;
* 📊 метрики качества с **разбивкой по штрафам и бонусам**.
""")

# --- состояние сессии ---
if 'config' not in st.session_state:
    st.session_state.config = Config()
conf = st.session_state.config

# --- боковая панель ---
st.sidebar.header("⚙️ Параметры среды")
conf.AREA_SIZE        = st.sidebar.slider("Размер площадки (м)", 50, 500, conf.AREA_SIZE)
conf.MIN_DIST_TO_ROAD = st.sidebar.slider("Мин. расстояние до дороги (м)", 1, 20, conf.MIN_DIST_TO_ROAD)
conf.ROAD_WIDTH       = st.sidebar.slider("Ширина дороги (м)", 2, 20, conf.ROAD_WIDTH)
show_grid             = st.sidebar.checkbox("Показывать дискретную сетку", value=True)

st.sidebar.subheader("Штрафы")
conf.PENALTY_ROAD_VIOLATION = st.sidebar.number_input("Штраф: дороги", value=float(conf.PENALTY_ROAD_VIOLATION))
conf.PENALTY_FIRE_SAFETY    = st.sidebar.number_input("Штраф: пож. безопасность", value=float(conf.PENALTY_FIRE_SAFETY))
conf.PENALTY_COLLISION      = st.sidebar.number_input("Штраф: коллизии", value=float(conf.PENALTY_COLLISION))

st.sidebar.subheader("Бонусы")
conf.BONUS_ROAD_PROXIMITY = st.sidebar.number_input("Бонус: близость к дороге", value=float(conf.BONUS_ROAD_PROXIMITY))
conf.BONUS_COMPACTNESS    = st.sidebar.number_input("Бонус: компактность",       value=float(conf.BONUS_COMPACTNESS))
conf.BONUS_TECH_LINK      = st.sidebar.number_input("Бонус: тех. связи",         value=float(conf.BONUS_TECH_LINK))

# --- загрузка данных ---
dl = DataLoader(conf)
try:
    distances, sequence, characteristics = dl.load_data()
    st.sidebar.success(f"Загружено объектов: {len(characteristics)}")
except Exception as e:
    st.error(f"Ошибка загрузки Excel: {e}")
    st.stop()

st.subheader("📋 Список объектов для размещения")
df_objects = pd.DataFrame(characteristics.numpy(), columns=['Длина', 'Ширина', 'Радиус'])
df_objects.index = [f"#{i + 1}" for i in range(len(df_objects))]
st.dataframe(df_objects)

if st.button("🚀 Запустить размещение"):
    with st.spinner("Нейросеть рассчитывает оптимальные позиции..."):
        model = PlacementRNN(conf).to(conf.DEVICE)
        if os.path.exists(conf.MODEL_SAVE_PATH):
            ckpt = torch.load(conf.MODEL_SAVE_PATH, map_location=conf.DEVICE, weights_only=False)
            try:
                model.load_state_dict(ckpt['model_state_dict'])
            except Exception:
                pass

        placer = ObjectPlacer(conf, distances, sequence, characteristics)
        predictor = Predictor(conf, model, placer)
        predictor.place_all_objects()
        breakdown = placer.calculate_quality_breakdown()

    st.subheader("🗺️ Карта размещения")
    col1, col2 = st.columns([3, 1])

    with col1:
        fig, ax = plt.subplots(figsize=(10, 10))
        ax.add_patch(mpatches.Rectangle((0, 0), conf.AREA_SIZE, conf.AREA_SIZE,
                                        facecolor="#f7f9fc", edgecolor="black"))

        for road_type, coord in conf.ROADS:
            half_w = conf.ROAD_WIDTH / 2
            if road_type == 'h':
                ax.add_patch(mpatches.Rectangle((0, coord - half_w),
                                                conf.AREA_SIZE, conf.ROAD_WIDTH,
                                                color='gray', alpha=0.6))
            else:
                ax.add_patch(mpatches.Rectangle((coord - half_w, 0),
                                                conf.ROAD_WIDTH, conf.AREA_SIZE,
                                                color='gray', alpha=0.6))

        for i, (x, y) in enumerate(placer.positions):
            obj_idx = placer.placed_objects[i]
            shape_type, dims = placer.get_object_shape(obj_idx)
            if shape_type == 'circle':
                ax.add_patch(mpatches.Circle((x, y), dims, facecolor='#4a90e2',
                                             edgecolor='black', alpha=0.75))
            else:
                l, w = dims
                ax.add_patch(mpatches.Rectangle((x - w / 2, y - l / 2), w, l,
                                                facecolor='#7ed321',
                                                edgecolor='black', alpha=0.75))
            ax.text(x, y, str(obj_idx + 1), color='white',
                    ha='center', va='center', fontweight='bold')

        if show_grid:
            step = max(1, conf.GRID_RESOLUTION) * 5
            ax.set_xticks(np.arange(0, conf.AREA_SIZE + 1, step))
            ax.set_yticks(np.arange(0, conf.AREA_SIZE + 1, step))
            ax.grid(True, alpha=0.35, linestyle='--', linewidth=0.5)

        ax.set_xlim(0, conf.AREA_SIZE)
        ax.set_ylim(conf.AREA_SIZE, 0)
        ax.set_aspect('equal')
        ax.set_xlabel("X, м")
        ax.set_ylabel("Y, м")
        st.pyplot(fig)

    with col2:
        st.metric("ИТОГ", f"{breakdown['total']:.1f}")
        st.markdown("**Штрафы**")
        st.write(f"Дороги: −{breakdown['penalty_road']:.1f}")
        st.write(f"Пож. безопасность: −{breakdown['penalty_fire']:.1f}")
        st.write(f"Коллизии: −{breakdown['penalty_collision']:.1f}")
        st.markdown("**Бонусы**")
        st.write(f"Близость к дороге: +{breakdown['bonus_road']:.1f}")
        st.write(f"Компактность: +{breakdown['bonus_compact']:.1f}")
        st.write(f"Тех. связи: +{breakdown['bonus_tech']:.1f}")

        st.markdown("**Координаты**")
        pos_df = pd.DataFrame(placer.positions, columns=['X', 'Y'])
        pos_df.index = [f"#{placer.placed_objects[i] + 1}" for i in range(len(placer.positions))]
        st.dataframe(pos_df)

st.markdown("---")
st.caption("Разработано в рамках курса 'Разработка ИИ-решений в индустрии'")
