import random
import math

import numpy as np
import torch


class ObjectPlacer:
    """
    Класс для последовательного размещения объектов на дискретной сетке
    с учётом геометрии, дорог, противопожарных требований и технологических связей.

    Все координаты — в метрах. Сетка имеет шаг GRID_RESOLUTION (по умолчанию 1 м).
    grid[y, x] = 0       — свободная клетка
                 -1      — дорога (нельзя занимать)
                 idx+1   — занято объектом с индексом idx
    """

    # --- значения, которыми заполнена сетка ---
    EMPTY = 0
    ROAD = -1

    def __init__(self, config, distances, sequence, characteristics):
        self.config = config
        self.area_size = int(config.AREA_SIZE)
        self.distances = distances           # (N, N) тензор минимальных расстояний
        self.sequence = sequence             # (N, N) тензор технологических связей (0/1)
        self.characteristics = characteristics  # (N, 3) тензор [L, W, R]
        self.num_objects = characteristics.shape[0]

        # Создаём маску дорог
        self._build_road_mask()
        self.reset()

    # ------------------------------------------------------------------ #
    # СЛУЖЕБНЫЕ
    # ------------------------------------------------------------------ #

    def _build_road_mask(self):
        """Маска дорог: 1 — дорога, 0 — земля. Индексация [y, x]."""
        self.road_mask = torch.zeros((self.area_size, self.area_size))
        for road_type, coord in self.config.ROADS:
            half_w = self.config.ROAD_WIDTH / 2
            if road_type == 'h':                                  # горизонтальная: фиксирован Y
                y_start = max(0, int(coord - half_w))
                y_end = min(self.area_size, int(coord + half_w))
                self.road_mask[y_start:y_end, :] = 1
            else:                                                 # вертикальная: фиксирован X
                x_start = max(0, int(coord - half_w))
                x_end = min(self.area_size, int(coord + half_w))
                self.road_mask[:, x_start:x_end] = 1

    def reset(self):
        """Полностью очищаем сетку, оставляя только дороги."""
        self.grid = torch.zeros((self.area_size, self.area_size))
        self.grid[self.road_mask == 1] = self.ROAD
        self.placed_objects = []   # список индексов размещённых объектов (в порядке размещения)
        self.positions = []        # список (x, y) для каждого размещённого объекта

    def get_object_shape(self, obj_idx):
        """Возвращает форму и габариты объекта.
        Returns:
            ('circle',    r)      — круг радиуса r
            ('rectangle', (l, w)) — прямоугольник L x W
        """
        char = self.characteristics[obj_idx]
        l, w, r = char[0].item(), char[1].item(), char[2].item()
        if r > 0:
            return 'circle', r
        return 'rectangle', (l, w)

    def object_half_size(self, obj_idx):
        """Грубый «радиус» объекта для оценок расстояний от центра."""
        shape, dims = self.get_object_shape(obj_idx)
        if shape == 'circle':
            return dims
        l, w = dims
        return max(l, w) / 2.0

    # ------------------------------------------------------------------ #
    # ГЕОМЕТРИЯ
    # ------------------------------------------------------------------ #

    def get_dist_to_nearest_road(self, x, y):
        """Расстояние от точки (x, y) до ближайшего края любой дороги."""
        if not self.config.ROADS:
            return float('inf')
        min_d = float('inf')
        half_w = self.config.ROAD_WIDTH / 2.0
        for r_type, coord in self.config.ROADS:
            d = abs((y if r_type == 'h' else x) - coord) - half_w
            min_d = min(min_d, max(0.0, d))
        return min_d

    def can_place(self, x, y, obj_idx):
        """Проверка всех ограничений размещения."""
        shape_type, dims = self.get_object_shape(obj_idx)
        half = self.object_half_size(obj_idx)

        # 1. Расстояние от объекта до края дороги >= MIN_DIST_TO_ROAD
        d_road_center = self.get_dist_to_nearest_road(x, y)
        if (d_road_center - half) < self.config.MIN_DIST_TO_ROAD:
            return False

        # 2. Границы поля и коллизии с другими объектами/дорогами
        if shape_type == 'circle':
            r = int(math.ceil(dims))
            if x - r < 0 or x + r >= self.area_size or y - r < 0 or y + r >= self.area_size:
                return False
            sub_grid = self.grid[max(0, y - r):y + r + 1, max(0, x - r):x + r + 1]
            if torch.any(sub_grid != self.EMPTY):
                return False
        else:
            l, w = dims
            hl, hw = int(math.ceil(l / 2)), int(math.ceil(w / 2))
            if x - hw < 0 or x + hw >= self.area_size or y - hl < 0 or y + hl >= self.area_size:
                return False
            sub_grid = self.grid[max(0, y - hl):y + hl + 1, max(0, x - hw):x + hw + 1]
            if torch.any(sub_grid != self.EMPTY):
                return False

        # 3. Противопожарные расстояния (по краям габаритов)
        for i, (px, py) in enumerate(self.positions):
            other_idx = self.placed_objects[i]
            dist_centers = math.hypot(x - px, y - py)
            edge_dist = dist_centers - half - self.object_half_size(other_idx)
            min_req = self.distances[obj_idx, other_idx].item()
            if edge_dist < min_req:
                return False
        return True

    def place_object(self, position, obj_idx):
        """Размещаем объект на сетке и обновляем структуры."""
        x, y = int(position[0]), int(position[1])
        shape_type, dims = self.get_object_shape(obj_idx)
        if shape_type == 'circle':
            r = int(math.ceil(dims))
            for i in range(max(0, y - r), min(self.area_size, y + r + 1)):
                for j in range(max(0, x - r), min(self.area_size, x + r + 1)):
                    if math.hypot(j - x, i - y) <= dims:
                        self.grid[i, j] = obj_idx + 1
        else:
            l, w = dims
            hl, hw = int(math.ceil(l / 2)), int(math.ceil(w / 2))
            y0, y1 = max(0, y - hl), min(self.area_size, y + hl + 1)
            x0, x1 = max(0, x - hw), min(self.area_size, x + hw + 1)
            self.grid[y0:y1, x0:x1] = obj_idx + 1
        self.placed_objects.append(obj_idx)
        self.positions.append((x, y))

    # ------------------------------------------------------------------ #
    # МЕТРИКА КАЧЕСТВА
    # ------------------------------------------------------------------ #

    def calculate_quality_breakdown(self):
        """Подробная метрика качества с разбивкой по штрафам и бонусам.

        Returns:
            dict с ключами:
                penalty_road, penalty_fire, penalty_collision  — штрафы
                bonus_road,   bonus_compact, bonus_tech       — бонусы
                total                                          — итог
        """
        cfg = self.config
        out = dict(
            penalty_road=0.0, penalty_fire=0.0, penalty_collision=0.0,
            bonus_road=0.0,   bonus_compact=0.0, bonus_tech=0.0
        )
        if not self.positions:
            out['total'] = 0.0
            return out

        # --- по объектам: расстояние до дороги ---
        for i, (x, y) in enumerate(self.positions):
            obj_i = self.placed_objects[i]
            half = self.object_half_size(obj_i)
            actual_dist = self.get_dist_to_nearest_road(x, y) - half

            if actual_dist < cfg.MIN_DIST_TO_ROAD:
                out['penalty_road'] += cfg.PENALTY_ROAD_VIOLATION
            elif actual_dist - cfg.MIN_DIST_TO_ROAD <= cfg.IDEAL_ROAD_BAND:
                out['bonus_road'] += cfg.BONUS_ROAD_PROXIMITY

        # --- по парам объектов: противопожарные расстояния, компактность, связи ---
        n = len(self.positions)
        for i in range(n):
            obj_i = self.placed_objects[i]
            xi, yi = self.positions[i]
            half_i = self.object_half_size(obj_i)
            for j in range(i + 1, n):
                obj_j = self.placed_objects[j]
                xj, yj = self.positions[j]
                half_j = self.object_half_size(obj_j)

                dist_centers = math.hypot(xi - xj, yi - yj)
                edge_dist = dist_centers - half_i - half_j
                min_req = self.distances[obj_i, obj_j].item()

                # коллизия
                if edge_dist < 0:
                    out['penalty_collision'] += cfg.PENALTY_COLLISION
                # противопожарное нарушение
                elif edge_dist < min_req:
                    out['penalty_fire'] += cfg.PENALTY_FIRE_SAFETY
                # компактность: зазор близок к минимуму
                elif 0 <= (edge_dist - min_req) <= 10:
                    out['bonus_compact'] += cfg.BONUS_COMPACTNESS

                # технологическая связь — бонус обратно пропорционален расстоянию
                tech_link = self.sequence[obj_i, obj_j].item()
                if tech_link > 0:
                    out['bonus_tech'] += cfg.BONUS_TECH_LINK / max(1.0, edge_dist) * tech_link

        out['total'] = (
            -out['penalty_road'] - out['penalty_fire'] - out['penalty_collision']
            + out['bonus_road'] + out['bonus_compact'] + out['bonus_tech']
        )
        return out

    def calculate_quality(self):
        """Совместимость со старым кодом — возвращает только итоговое значение."""
        return self.calculate_quality_breakdown()['total']

    # ------------------------------------------------------------------ #
    # ВСПОМОГАТЕЛЬНОЕ ДЛЯ RNN / ТРЕНИРОВКИ
    # ------------------------------------------------------------------ #

    def get_available_positions(self):
        """Все клетки, в которые ещё не положили объект и нет дороги."""
        avail = torch.where(self.grid == self.EMPTY)
        return list(zip(avail[1].tolist(), avail[0].tolist()))  # (x, y)

    def get_object_features(self, obj_idx):
        """Вектор признаков объекта, подаваемый в RNN.
        Размер вектора — config.INPUT_SIZE (12)."""
        char = self.characteristics[obj_idx]
        feat = torch.zeros(self.config.INPUT_SIZE)
        feat[0:3] = char / self.area_size                          # габариты, нормированные
        feat[3] = len(self.placed_objects) / max(1, self.num_objects)  # прогресс

        # средняя позиция уже размещённых объектов
        if self.positions:
            xs = [p[0] for p in self.positions]
            ys = [p[1] for p in self.positions]
            feat[4] = sum(xs) / len(xs) / self.area_size
            feat[5] = sum(ys) / len(ys) / self.area_size
        else:
            feat[4] = 0.5
            feat[5] = 0.5

        # информация о первой дороге
        if self.config.ROADS:
            r_type, coord = self.config.ROADS[0]
            feat[6] = coord / self.area_size
            feat[7] = 1.0 if r_type == 'h' else 0.0

        # связи текущего объекта с уже размещёнными
        link_sum = sum(self.sequence[obj_idx, p].item() for p in self.placed_objects)
        feat[8] = min(link_sum / max(1, self.num_objects), 1.0)

        # доля свободного пространства
        total_cells = self.area_size * self.area_size
        free_cells = (self.grid == self.EMPTY).sum().item()
        feat[9] = free_cells / total_cells

        # средний требуемый отступ от размещённых
        if self.placed_objects:
            avg_dist = (sum(self.distances[obj_idx, p].item() for p in self.placed_objects)
                        / len(self.placed_objects))
            feat[10] = avg_dist / self.area_size

        # форма: 0 = прямоугольник, 1 = круг
        feat[11] = 1.0 if char[2].item() > 0 else 0.0
        return feat

    def create_training_data(self, num_samples):
        """Создаёт обучающие траектории — последовательности (features, target_pos).

        Возвращает:
            sequences: list[Tensor (T, INPUT_SIZE)]  — признаки на каждом шаге траектории
            targets:   list[Tensor (T, 2)]            — нормированные координаты целей
        Длина T одинакова внутри одной траектории.
        """
        sequences, targets = [], []
        for _ in range(num_samples):
            self.reset()
            seq_feats, seq_tgts = [], []
            order = list(range(self.num_objects))
            random.shuffle(order)
            for step in order:
                feat = self.get_object_features(step)
                avail = self.get_available_positions()
                if not avail:
                    break

                placed = False
                random.shuffle(avail)
                for p in avail[:200]:
                    if self.can_place(p[0], p[1], step):
                        self.place_object(p, step)
                        seq_feats.append(feat)
                        seq_tgts.append(torch.tensor(
                            [p[0] / self.area_size, p[1] / self.area_size], dtype=torch.float32))
                        placed = True
                        break
                if not placed:
                    break
            if seq_feats:
                sequences.append(torch.stack(seq_feats))
                targets.append(torch.stack(seq_tgts))
        return sequences, targets
