"""Точка входа для запуска из командной строки.

Режимы:
    --mode gui      — графический интерфейс (по умолчанию)
    --mode train    — только обучение
    --mode predict  — только размещение (с использованием сохранённой модели)
    --mode both     — обучить и сразу же разместить
"""

import argparse

import numpy as np
import torch

from config import Config
from data_loader import DataLoader
from models import PlacementRNN
from placer import ObjectPlacer
from predict import Predictor
from train import Trainer
from visualize import Visualizer


def set_seed(config):
    torch.manual_seed(config.SEED)
    np.random.seed(config.SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config.SEED)


def main():
    parser = argparse.ArgumentParser(description='RNN-размещение объектов')
    parser.add_argument('--mode', type=str, default='gui',
                        choices=['train', 'predict', 'both', 'gui'])
    parser.add_argument('--load_model', type=str, default=None)
    args = parser.parse_args()

    if args.mode == 'gui':
        print("Запуск графического интерфейса...")
        from gui_app import App
        App().mainloop()
        return

    config = Config()
    set_seed(config)

    distances, sequence, characteristics = DataLoader(config).load_data()
    config.sequence_data = sequence
    config.characteristics_tensor = characteristics

    model = PlacementRNN(config).to(config.DEVICE)
    placer = ObjectPlacer(config, distances, sequence, characteristics)
    visualizer = Visualizer(config)

    if args.mode in ('train', 'both'):
        print("\n=== ОБУЧЕНИЕ ===")
        trainer = Trainer(config, model, placer)
        if args.load_model:
            trainer.load_model(args.load_model)
        losses = trainer.train()
        trainer.save_model()
        visualizer.plot_training_history(losses)

    if args.mode in ('predict', 'both'):
        print("\n=== РАЗМЕЩЕНИЕ ===")
        if args.mode == 'predict':
            trainer = Trainer(config, model, placer)
            trainer.load_model(args.load_model or config.MODEL_SAVE_PATH)
        predictor = Predictor(config, model, placer)
        predictor.place_all_objects()
        predictor.save_results()
        breakdown = placer.calculate_quality_breakdown()
        visualizer.visualize_placement(placer, placer.positions, quality_breakdown=breakdown)
        visualizer.print_statistics(placer, placer.positions, breakdown)

    print("\nГотово!")


if __name__ == "__main__":
    main()
